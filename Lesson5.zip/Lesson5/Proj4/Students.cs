﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj4
{
    class Students
    {       
        public string Surname
        {
            get { return surname; }
            set { if (value.Length <= 20) surname = value; }
        }
        public string Name
        {
            get { return name; }
            set { if (value.Length <= 15) name = value; }
        }
        public double AverageSum { get; set; }

        public List<int> evaluations = new List<int>(); // для варианта, если больше 3 оценок, что бы жестко не указывать
        public Students(string surname, string name, List<int> evaluations, double averagesum)
        {
            Surname = surname;
            Name = name;
            this.evaluations = evaluations;
            AverageSum = averagesum;
        }
        public static int CompareAverageSum(Students students1, Students student2) => students1.AverageSum.CompareTo(student2.AverageSum);
        string surname;
        string name;
    }
}
