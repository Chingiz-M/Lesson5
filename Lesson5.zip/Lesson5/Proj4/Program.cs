﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj4
{
    class Program
    {
        /*
        Задание: 4. Задача ЕГЭ.
                    *На вход программе подаются сведения о сдаче экзаменов учениками 9-х классов некоторой средней
                    школы. В первой строке сообщается количество учеников N, которое не меньше 10, но не
                    превосходит 100, каждая из следующих N строк имеет следующий формат:
                    <Фамилия> <Имя> <оценки>,
                    где <Фамилия> — строка, состоящая не более чем из 20 символов, <Имя> — строка, состоящая не
                    более чем из 15 символов, <оценки> — через пробел три целых числа, соответствующие оценкам по
                    пятибалльной системе. <Фамилия> и <Имя>, а также <Имя> и <оценки> разделены одним пробелом.
                    Пример входной строки:
                    Иванов Петр 4 5 3
                    Требуется написать как можно более эффективную программу, которая будет выводить на экран
                    фамилии и имена трёх худших по среднему баллу учеников. Если среди остальных есть ученики,
                    набравшие тот же средний балл, что и один из трёх худших, следует вывести и их фамилии и имена.
         Фамилия: Орлов
         */
        static void Main(string[] args)
        {
            Console.Title = "Задача ЕГЭ";

            List<Students> students = GetStudents();
            students.Sort(Students.CompareAverageSum); // отсортировал по средним оценкам
            Print(students);
            Console.ReadKey(true);

        }

        static public List<Students> GetStudents()
        {
            List<Students> students = new List<Students>();
            using (StreamReader sr = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "file.txt"))
            {
                int count = int.Parse(sr.ReadLine());
                for(int i = 0; i < count; i++)
                {
                    string[] temp = sr.ReadLine().Split(' ');
                    List<int> evaluations = new List<int>();
                    for (int j = 2; j < temp.Length; j++)
                        evaluations.Add(int.Parse(temp[j]));
                    students.Add(new Students(temp[0], temp[1], evaluations, GetAverageSum(evaluations)));
                }
            }
            return students;
        }
        static double GetAverageSum(List<int> evaluations)
        {
            double result = 0;
            foreach (int i in evaluations)
                result += i;
            return Math.Round(result / evaluations.Count, 3);
        }
        static public void Print(List<Students> students)
        {
            Console.WriteLine("Имена 3-х (и более) учеников с худшим средним баллом:");
            for(int i = 0; i < students.Count; i++)
            {
                if(i < 3)
                    Console.WriteLine($"Студент: {students[i].Surname} {students[i].Name} со средним баллом {students[i].AverageSum}");
                // сравниваю с 3 элементом, т.к. он либо равен 2-му либо меньше, аналогично и между первым и вторым элементом, ну ,думаю, здесь все понятно
                if (students[i].AverageSum == students[2].AverageSum && i > 2) 
                    Console.WriteLine($"Студент: {students[i].Surname} {students[i].Name} со средним баллом {students[i].AverageSum}");
            }
        }
    }
}
