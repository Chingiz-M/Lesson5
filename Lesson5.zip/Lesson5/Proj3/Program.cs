﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj3
{
    class Program
    {
        /*
        Задание: 3. *Для двух строк написать метод, определяющий, является ли одна строка перестановкой другой.
                    Регистр можно не учитывать:
                    а) с использованием методов C#;
                    б) *разработав собственный алгоритм.
         Фамилия: Орлов
         */
        static void Main(string[] args)
        {
            Console.Title = "Перестановка";
            Permutation("Cлово", "оCлов");
            Permutation("Cлово", "оCловв");
            MyPermutation("Cлово", "оCлов");
            MyPermutation("Cлово", "оCлок");

            Console.ReadKey(true);

        }

        public static void Permutation(string word1, string word2)
        {
            var w1 = word1.ToLower().ToList();
            var w2 = word2.ToLower().ToList();
            w1.Sort();
            w2.Sort();
            if (w1.SequenceEqual(w2))
                Console.WriteLine($"Слово '{word1}' является перестановкой слова '{word2}' ");
            else
                Console.WriteLine($"Слово '{word1}' не является перестановкой слова '{word2}' ");
        }
        public static void MyPermutation(string word1, string word2)
        {
            if(word1.Length != word2.Length)
                Console.WriteLine($"Слово '{word1}' не является перестановкой слова '{word2}' ");
            else
            {
                var pairs = GetDictionaryWord(word1);
                foreach (char c in word2)
                {
                    foreach (char k in pairs.Keys)
                        if (c == k)
                        {
                            pairs[k]--;
                            break;
                        }
                }
                bool result = true;
                foreach (char k in pairs.Keys)
                    if (pairs[k] != 0)
                        result = false;
                if(result)
                    Console.WriteLine($"Слово '{word1}' является перестановкой слова '{word2}' ");
                else
                    Console.WriteLine($"Слово '{word1}' не является перестановкой слова '{word2}' ");
            }
        }
        public static Dictionary<char,int> GetDictionaryWord(string word1)
        {
            Dictionary<char, int> pairs = new Dictionary<char, int>(word1.Length);
            foreach (char c in word1)
            {
                bool check = false;
                foreach (char k in pairs.Keys)
                    if (c == k) // не стал использовать Contains, т.к. задание без методов c#
                    {
                        pairs[k]++;
                        check = true;
                        break;
                    }
                if (!check)
                    pairs.Add(c, 1);
            }
            return pairs;
        }
    }
}
