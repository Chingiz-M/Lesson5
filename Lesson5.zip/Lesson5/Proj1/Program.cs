﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Proj1
{
    class Program
    {
        /*
        Задание: 1. Создать программу, которая будет проверять корректность ввода логина. Корректным логином будет строка от 2 до 10
                    символов, содержащая только буквы латинского алфавита или цифры, при этом цифра не может быть первой:
                 а) без использования регулярных выражений;
                 б) с использованием регулярных выражений.
         Фамилия: Орлов
         */
        static void Main(string[] args)
        {
            Console.Title = "Корректность логина";
            CheckLoginWithoutRegex();
            CheckLoginWithRegex();
            Console.ReadKey(true);
        }
        public static void CheckLoginWithoutRegex()
        {
            bool check = false;
            Console.Write("Введите логин: ");
            string login = Console.ReadLine();
            if (char.GetNumericValue(login[0]) == -1 && (login.Length > 1 && login.Length < 11))
            {
                foreach(char letter in login)
                {
                    if (char.IsLetterOrDigit(letter))
                        check = true;
                    else
                    {
                        check = false;
                        break;
                    }
                }
                if(check)
                    Console.WriteLine("Вы ввели корректный логин!");
                else
                    Console.WriteLine("Вы ввели некорректный логин!");
            }
            else
                Console.WriteLine("Вы ввели некорректный логин!");
        }
        public static void CheckLoginWithRegex()
        {
            Regex regex = new Regex("^[A-Za-z]{1}[A-Za-z0-9]{1,9}$");
            Console.Write("Введите логин: ");
            string login = Console.ReadLine();
            if (regex.IsMatch(login))
                Console.WriteLine("Вы ввели корректный логин!");
            else
                Console.WriteLine("Вы ввели некорректный логин!");
        }
    }
}
