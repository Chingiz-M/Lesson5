﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj2
{
    class Program
    {
        /*
        Задание: 2. Разработать класс Message, содержащий следующие статические методы для обработки текста:
                а) Вывести только те слова сообщения, которые содержат не более n букв.
                б) Удалить из сообщения все слова, которые заканчиваются на заданный символ.
                в) Найти самое длинное слово сообщения.
                г) Сформировать строку с помощью StringBuilder из самых длинных слов сообщения.
                Продемонстрируйте работу программы на текстовом файле с вашей программой.
         Фамилия: Орлов
         */
        static void Main(string[] args)
        {
            Console.Title = "Класс Message";
            Console.WriteLine(File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "file.txt"));
            Message.GetWordsN(3);
            Message.DeleteWordsN('е');
            Message.GetMaxWord();
            Message.GetMaxWords(); // печальное предложение получилось
            Console.ReadKey(true);

        }
    }
}
