﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj2
{
    class Message
    {
        public static void GetWordsN(int max)
        {
            Console.Write($"Слова, длиной не больше {max}: ");
            string[] str = GetArray();
            foreach (string s in str)
                if (s.Length <= max && s.Length > 0)
                    Console.Write(s + "; ");
            Console.WriteLine();

        }
        public static void DeleteWordsN(char endsymbol)
        {
            Console.Write($"Сообщение без слов с окончанием на '{endsymbol}': ");
            string[] str = GetArray();
            foreach (string s in str)
                if(s.Length > 0)
                    if (s[s.Length - 1] != endsymbol)
                        Console.Write(s + " ");
            Console.WriteLine();
        }
        public static void GetMaxWord()
        {
            Console.Write($"Самое длинное слово: ");
            int max = 1;
            string[] str = GetArray();
            foreach (string s in str)
                if (s.Length > max)
                    max = s.Length;
            foreach (string s in str)
                if (s.Length == max)
                {
                    Console.Write(s); // вывожу первое слово с наибольшей длиной
                    break;
                }
            Console.WriteLine();
        }
        public static void GetMaxWords()
        {
            Console.Write($"Слово из самых длинных слов: ");
            int max = 1;
            string[] str = GetArray();
            foreach (string s in str)
                if (s.Length > max)
                    max = s.Length;
            StringBuilder result = new StringBuilder();
            foreach (string s in str)
                if (s.Length == max)
                    result.Append(s);
            Console.Write(result);
            Console.WriteLine();
        }
        static string[] GetArray()
        {
            StringBuilder temp = new StringBuilder(File.ReadAllText(AppDomain.CurrentDomain.BaseDirectory + "file.txt"));
            for (int i = 0; i < temp.Length; i++)
                if (char.IsPunctuation(temp[i]))
                    temp.Remove(i, 1);
            return temp.ToString().Replace("\r\n"," ").Split(' ');
        }
    }
}
