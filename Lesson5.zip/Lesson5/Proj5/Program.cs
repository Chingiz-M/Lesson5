﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;

namespace Proj5
{
    class Program
    {
        /*
        Задание: 5. **Написать игру «Верю. Не верю». 
                 В файле хранятся вопрос и ответ, правда это или нет. Например: «Шариковую ручку изобрели в древнем Египте», «Да».
                 Компьютер загружает эти данные, случайным образом выбирает 5 вопросов и задаёт их игроку. 
                 Игрок отвечает Да или Нет на каждый вопрос и набирает баллы за каждый правильный ответ. 
         Фамилия: Орлов
         */
        static void Main(string[] args)
        {
            Console.Title = "Игра «Верю. Не верю»";

            Print(GetFile());
            Console.ReadKey(true);

        }
        static public List<Sentenses> GetFile()
        {
            List<Sentenses> sentenses = new List<Sentenses>();

            using (StreamReader sr = new StreamReader(AppDomain.CurrentDomain.BaseDirectory + "file.txt"))
            {
                string pattern = @"(.*\?)\s(.{2,3})";
                while (!sr.EndOfStream)
                {
                    foreach (Match match in Regex.Matches(sr.ReadLine(), pattern))
                        sentenses.Add(new Sentenses(match.Groups[1].Value, (match.Groups[2].Value)));
                }
            }
            return sentenses;
        }
        static public void Print(List<Sentenses> sentenses)
        {
            Random random = new Random();
            int count = 0;
            for(int i = 0; i < 5;)
            {
                int rand = random.Next(1, 34);
                if (!sentenses[rand].CHeck)
                {
                    sentenses[rand].CHeck = true;
                    Console.Write(sentenses[rand].Question + "\nВведите ответ: ");
                    string answer = Console.ReadLine();
                    if (answer.ToLower() == sentenses[rand].Answer.ToLower())
                        count++;
                    i++;
                    Console.WriteLine();
                }
            }
            string word = String.Empty;
            if(count == 0 || count == 5) word = "загадок";
            else if (count == 1 ) word = "загадку";
            else word = "загадки";
            Console.WriteLine($"Вы отгадали {count} {word}");

        }
    }
}
